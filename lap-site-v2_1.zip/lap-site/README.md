# LAP — waitlist / demo site

A static, no-backend preview site for LAP (Loud And Proud), a project by
The Backup Plan. It is **not** a working store — there's no cart, no
payments, no login, and no real product catalog. Every "Add to Bag"
click opens the waitlist modal instead. That's intentional: this is a
validation tool, not a launch.

## Why it's built this way

There's no server, no database, and no auth system — which means there's
close to nothing here for an attacker to actually break into. A landing
page can't leak a password database it doesn't have. Once you're ready
to sell real products, that's a different, much bigger build (payments,
inventory, accounts) and deserves its own security review at that time
— don't bolt real checkout onto this project without that.

## Run it locally

No build step, no dependencies. Just open `index.html` in a browser, or
serve it locally so relative paths behave the same as in production:

```bash
cd lap-site
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Connect the waitlist / feedback forms to something real

Right now, form submissions with no endpoint configured are saved to
the visitor's own browser (`localStorage`) only — nothing leaves their
device, which is why the current version is safe to put live as-is but
also **isn't actually collecting emails for you yet**.

To actually receive submissions:

1. Create a free form-handling account yourself at
   [formspree.io](https://formspree.io) (or Getform, Basin — any
   service that gives you a POST endpoint). Claude/this assistant did
   not and cannot create this account for you — sign up yourself so
   the account and its data belong to you.
2. Copy the endpoint URL Formspree gives you.
3. Open `js/main.js` and set:
   ```js
   const FORM_ENDPOINT = 'https://formspree.io/f/your-real-id';
   ```
4. If you deploy on Netlify, the `_headers` file already allow-lists
   `formspree.io` in the Content-Security-Policy. If you use a
   different form service, update the CSP `connect-src` and
   `form-action` values in **both** `_headers` and the `<meta
   http-equiv="Content-Security-Policy">` tag in `index.html` — and in
   `vercel.json` if you deploy on Vercel instead — to match, or
   submissions will be silently blocked by the browser.

## Deploy

Any static host works. Two free options:

**Netlify** — drag the folder into Netlify's dashboard, or connect
the GitHub repo. `_headers` is picked up automatically.

**Vercel** — `vercel deploy` from this folder, or connect the repo.
`vercel.json` is picked up automatically.

**GitHub Pages** — push to GitHub, enable Pages on the repo. Note
GitHub Pages doesn't support custom response headers, so the
`<meta>` CSP tag in `index.html` is your main protection there — the
`_headers` / `vercel.json` files simply won't apply.

## Push to GitHub

```bash
cd lap-site
git add .
git commit -m "Initial LAP waitlist site"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

You'll need to authenticate with your own GitHub credentials (a
personal access token or the GitHub CLI/`gh auth login`) — do this
yourself in your own terminal; don't paste tokens or passwords into
a chat with any AI assistant, including this one.

## Before you take this further

- `robots.txt` currently blocks all search indexing — remove that
  once you're ready to actually be found.
- The product grid and "drops" strip use placeholder names and
  colour blocks, not real product photos — swap in real imagery
  once you have brand partners, and keep image files reasonably
  compressed (WebP, &lt;200KB each) so the site stays fast.
- Update `<meta name="robots">` in `index.html` to match `robots.txt`
  when you're ready to go public.
- This project intentionally has zero third-party JavaScript
  dependencies (no analytics, no trackers, no CDN scripts) to keep
  the attack surface minimal. If you add any — analytics, a chat
  widget, etc. — update the CSP `script-src` and `connect-src`
  directives in both places (`_headers`/`vercel.json` and the
  `<meta>` tag) to match, and prefer self-hosted/loaded-with-SRI
  scripts over blindly trusted third-party `<script src>` tags.
